package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.player.AdventureParty;

public class CardinalDirectionsCommand extends Command {
	private String direction;

	/**
	 * Create a new CardinalDirectionsCommand object.
	 * 
	 */
	public CardinalDirectionsCommand(String direction) {
		this.direction = direction;
	}

	@Override
	public boolean execute(Player p) {
		AdventureParty player = (AdventureParty) p;
		DungeonRoom room = player.getCurrentRoom().getExit(direction);

		if (room != null) {
			player.walk(direction);
		} else {
			System.out.println("\nThis room doesn't contain that exit!");
			System.out.println("Please enter a new command.");
		}

		return false;
	}
}
