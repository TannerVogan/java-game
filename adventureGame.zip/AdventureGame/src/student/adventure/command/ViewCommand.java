package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.player.AdventureParty;

public class ViewCommand extends Command {

	@Override
	public boolean execute(Player p) {
		if (hasSecondWord()) {
			AdventureParty player = (AdventureParty) p;
			DungeonRoom room = player.getCurrentRoom();

			if (getSecondWord().equalsIgnoreCase("inventory")) {
				System.out.println(player.getInventory().getDescription());
			} else if (getSecondWord().equalsIgnoreCase("hero")) {
				System.out.println(player.getHero().getStats());
			} else if (getSecondWord().equalsIgnoreCase("monsters")) {
				System.out.println(room.getMonstersDescription());
			} else if (getSecondWord().equalsIgnoreCase("items")) {
				System.out.println(room.getItemsDescription());
			} else if (getSecondWord().equalsIgnoreCase("room")) {
				System.out.println(room.getLongDescription());
			} else {
				System.out.println("You can only view inventory, hero, monsters, room and " + "items.");
			}
		} else {
			System.out.println("You must specify what you want to view.");
			System.out.println("You can view inventory, hero, room, monsters and items.");
			System.out.println("example: view monsters");
			System.out.println();
		}

		return false;
	}
}
