package student.adventure.command;

import student.adventure.Command;
import student.adventure.Player;
import student.adventure.player.AdventureParty;

public class InventoryCommand extends Command {

	@Override
	public boolean execute(Player p) {
		AdventureParty player = (AdventureParty) p;
		System.out.println(player.getInventory().getDescription());
		return false;
	}
}
