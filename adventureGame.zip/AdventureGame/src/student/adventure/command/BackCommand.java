package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.character.Monster;
import student.adventure.player.AdventureParty;

public class BackCommand extends Command {

	@Override
	public boolean execute(Player p) {
		AdventureParty player = (AdventureParty) p;
		DungeonRoom room = player.getCurrentRoom();

		if (room.containsMonster()) {
			System.out.println();
			System.out.println(player.getCurrentRoom().getLongDescription());
			System.out.println("\tYou can't move! You have engaged in combat!");
			System.out.println("\tUse the flee command to move again.");
			System.out.print("Monsters:");
			for (Monster m : room.getMonsters()) {
				System.out.print(" " + m.getName() + " ");
			}
			System.out.println();
		} else if (player.getPreviousRoom() != null) {
			player.setCurrentRoom(player.getPreviousRoom());
			System.out.println();
			System.out.println(player.getCurrentRoom().getLongDescription());
		} else {
			System.out.println();
			System.out.println("You are still in the same room as when " + "the game started!");
		}
		return false;
	}
}
