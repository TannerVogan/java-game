package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

public class DropCommand extends Command {

	@Override
	public boolean execute(Player p) {
		AdventureParty player = (AdventureParty) p;
		DungeonRoom room = player.getCurrentRoom();

		if (hasSecondWord()) {
			UsableItem item = player.getInventory().getUsableItem(getSecondWord());

			if (item != null) {
				room.addItem(item);
				player.getInventory().removeUsableItem(item);
				System.out.println("Item " + item.getName() + " was removed from your inventory.");
			} else {
				System.out.println("You don't have " + getSecondWord() + " within your inventory!");
			}
		} else {
			System.out.println("You must specify which item to drop within " + "your inventory.");
			System.out.println("example: drop potion");
		}
		return false;
	}

}
