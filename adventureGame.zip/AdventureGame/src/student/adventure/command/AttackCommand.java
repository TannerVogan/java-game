package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.character.Hero;
import student.adventure.character.Monster;
import student.adventure.player.AdventureParty;

public class AttackCommand extends Command {

	@Override
	public boolean execute(Player p) {
		if (hasSecondWord()) {
			AdventureParty player = (AdventureParty) p;
			DungeonRoom room = player.getCurrentRoom();
			Monster monster = room.getMonster(getSecondWord());
			Hero hero = player.getHero();

			if (monster != null) {
				hero.attack(monster);

				if (monster.getHealth() <= 0) {
					monster.dropItems(room);
					room.removeMonster(monster.getName());
					System.out.println("You have killed " + monster.getName());
				}

				for (Monster m : room.getMonsters()) {
					m.attack(hero);
				}
			} else {
				System.out.println("Monster doesn't exist in this room!");
			}
		} else {
			System.out.println("You must specify the monster's name in which you wish to " + "attack.");
			System.out.println("example: attack goblin1");
		}
		return false;
	}
}
