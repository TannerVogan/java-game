package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

public class EquipCommand extends Command {

	@Override
	public boolean execute(Player p) {
		if (hasSecondWord()) {
			AdventureParty player = (AdventureParty) p;
			DungeonRoom room = player.getCurrentRoom();

			UsableItem item = player.getInventory().getUsableItem(getSecondWord());

			if (item != null) {
				UsableItem oldItem = player.getHero().changeEquipment(item.getPower(), item);
				System.out.println("\nYou have equiped " + item.getName() + "\n");

				if (oldItem != null) {
					room.addItem(oldItem);
				}
			} else {
				System.out.println("You must select an item found within your inventory.");
				System.out.println(player.getInventory().getDescription());
			}
		} else {
			System.out.println("You must specify which item to equip.");
			System.out.println("example: equip buckler");
		}
		return false;
	}
}
