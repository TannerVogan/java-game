package student.adventure.command;

import student.TestableRandom;
import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.character.Monster;
import student.adventure.player.AdventureParty;

public class FleeCommand extends Command {

	@Override
	public boolean execute(Player p) {
		AdventureParty player = (AdventureParty) p;
		DungeonRoom room = player.getCurrentRoom();

		if (!hasSecondWord()) {
			System.out.println(room.getLongDescription());
			System.out.println("You didn't specify which direction to run!");
			return false;
		} else if (!room.containsMonster()) {
			System.out.println("What are you running from?");
			return false;
		} else if (new TestableRandom().nextInt(10) < 4) {
			p.walk(getSecondWord());
		} else {
			System.out.println("Fleeing has failed!");
			for (Monster monster : room.getMonsters()) {
				monster.attack(player.getHero());
			}
		}
		return false;
	}
}
