package student.adventure.command.test;

import student.adventure.DungeonRoom;
import student.adventure.command.DropCommand;
import student.adventure.item.Item;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * DropCommandTest is a JUnit test class for DropCommand.
 *
 */
public class DropCommandTest extends student.TestCase {
	private DropCommand command;
	private AdventureParty p;

	/**
	 * Create a new DropCommandTest object.
	 */
	public DropCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		DungeonRoom r1 = new DungeonRoom("Room 1");
		command = new DropCommand();
		p = new AdventureParty();

		p.getInventory().addUsableItem(new UsableItem("Pendant", "Tyrael's magical pendant.", "health", 20, 1.50));
		r1.addItem(new Item("Table", "An old wooden table."));

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests execute no second word was entered
	 */
	public void testExecuteNoSecondWord() {
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You must specify which item to drop within your " + "inventory.\nexample: drop potion\n", output);
	}

	/**
	 * Tests execute with the correct item to drop.
	 */
	public void testExecuteDropItem() {
		command.setSecondWord("Pendant");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Item Pendant was removed from your inventory.\n", output);
	}

	/**
	 * Tests execute room doesn't have the item
	 */
	public void testExecuteItemDoesntExist() {
		command.setSecondWord("Sarcutus");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You don't have Sarcutus within your inventory!\n", output);
	}

}
