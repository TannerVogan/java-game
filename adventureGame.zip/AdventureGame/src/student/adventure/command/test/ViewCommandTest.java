package student.adventure.command.test;

import student.adventure.DungeonRoom;
import student.adventure.character.Monster;
import student.adventure.command.ViewCommand;
import student.adventure.item.Item;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * ViewCommandTest is a JUnit test class for ViewCommand.
 *
 */
public class ViewCommandTest extends student.TestCase {
	private ViewCommand command;
	private AdventureParty p;

	/**
	 * Create a new ViewCommandTest object.
	 */
	public ViewCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		DungeonRoom r1 = new DungeonRoom("Room 1");
		command = new ViewCommand();
		p = new AdventureParty();

		r1.addItem(new Item("table", "an old wooden table"));

		r1.addItem(new UsableItem("Medallion", "Zue's magical Medallion.", "health", 20, 1.50));
		r1.addMonster(new Monster("Troll", "Tough ugly creature with tough rock like skin.", 5, 5, 80, null));

		p.getInventory().addUsableItem(new UsableItem("axe", "small axe", "attack", 5, 1.00));

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests execute by trying to view the inventory
	 */
	public void testExecuteViewInventory() {
		command.setSecondWord("inventory");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Inventory: axe | \n\n", output);
	}

	/**
	 * Tests execute by trying to view the hero
	 */
	public void testExecuteViewHero() {
		command.setSecondWord("hero");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Name: Hokie Warrior | Attack: 10 | Defense: 5 | " + "Health: 100\nEquipped Items: \n\n", output);
	}

	/**
	 * Tests execute by trying to view the monsters
	 */
	public void testExecuteViewMonsters() {
		command.setSecondWord("monsters");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("\nMonsters: Name: Troll | Attack: 5 | Defense: 5 | " + "Health: 80\n\n\n", output);
	}

	/**
	 * Tests execute by trying to view the items
	 */
	public void testExecuteViewItems() {
		command.setSecondWord("items");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Items: table | Medallion | \n\n", output);
	}

	/**
	 * Tests execute by trying to view the room
	 */
	public void testExecuteViewRoom() {
		command.setSecondWord("room");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You are Room 1.\nExits:\n", output);
	}

	/**
	 * Tests execute by trying to view the default case
	 */
	public void testExecuteViewDefault() {
		command.setSecondWord("stars");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You can only view inventory, hero, monsters, room " + "and items.\n", output);
	}

	/**
	 * Tests execute by having no second word
	 */
	public void testExecuteViewNoSecondWord() {
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You must specify what you want to view."
				+ "\nYou can view inventory, hero, room, monsters and items." + "\nexample: view monsters\n\n", output);
	}
}
