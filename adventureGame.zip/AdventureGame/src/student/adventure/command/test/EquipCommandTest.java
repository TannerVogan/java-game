package student.adventure.command.test;

import student.adventure.DungeonRoom;
import student.adventure.command.EquipCommand;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * EquipCommandTest is a JUnit test class for EquipCommand.
 *
 */
public class EquipCommandTest
    extends student.TestCase
{
    private EquipCommand   command;
    private AdventureParty p;
    private UsableItem     item;
    private DungeonRoom    room;


    /**
     * Create a new EquipCommandTest object.
     */
    public EquipCommandTest()
    {
        // Empty constructor
    }


    /**
     * Sets up the test fixture. Called before every test case method.
     */
    public void setUp()
    {
        command = new EquipCommand();
        p = new AdventureParty();

        room = new DungeonRoom("a room!!!!");

        item = new UsableItem("axe", "small axe", "attack", 5, 1.00);

        p.getInventory().addUsableItem(item);

        p.setCurrentRoom(room);
    }


    /**
     * Tests execute by trying to equip the item
     */
    public void testExecuteEquipItem()
    {
        command.setSecondWord("axe");
        command.execute(p);
        String output = systemOut().getHistory();
        assertEquals("\nYou have equiped " + item.getName() + "\n\n", output);
    }


    /**
     * Tests execute by not having a second word
     */
    public void testExecuteNoSecondWord()
    {
        command.execute(p);
        String output = systemOut().getHistory();
        assertEquals(
            "You must specify which item to equip."
                + "\nexample: equip buckler\n",
            output);
    }


    /**
     * Tests execute by the player not having the item in his/her inventory
     */
    public void testExecuteDontHaveItem()
    {
        command.setSecondWord("a");
        command.execute(p);
        String output = systemOut().getHistory();
        assertEquals(
            "You must select an item found within your inventory."
                + "\nInventory: axe | \n\n",
            output);
    }


    /**
     * Tests execute by having something already equipped to the hero
     */
    public void testExecuteSomethingEquiped()
    {
        p.getHero().changeEquipment("attack", item);
        command.setSecondWord("axe");
        command.execute(p);
        assertEquals(item, room.getItem(item.getName()));
    }

}
