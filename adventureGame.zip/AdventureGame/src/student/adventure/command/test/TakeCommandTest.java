package student.adventure.command.test;

import student.adventure.DungeonRoom;
import student.adventure.command.TakeCommand;
import student.adventure.item.Item;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * TakeCommandTest is a JUnit test class for TakeCommand.
 *
 */
public class TakeCommandTest extends student.TestCase {
	private TakeCommand command;
	private AdventureParty p;
	private DungeonRoom r1;

	/**
	 * Create a new TakeCommandTest object.
	 */
	public TakeCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		command = new TakeCommand();
		p = new AdventureParty();
		r1 = new DungeonRoom("Room 1");

		r1.addItem(new Item("table", "a old wooden table"));

		r1.addItem(new UsableItem("Medallion", "Zue's magical medallion.", "health", 20, 1.50));

		r1.addItem(new UsableItem("axe", "Zue's magical axe.", "attack", 2000, 100.50));

		r1.addItem(new UsableItem("shield", "Zue's magical shield.", "defense", 2000, 5.50));

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests execute no second word was entered
	 */
	public void testExecuteNoSecondWord() {
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You must specify which item to take." + "\nexample: take potion\n", output);
	}

	/**
	 * Tests execute by taking Pendant and winning the game
	 */
	public void testExecuteTakeTyraelsPendant() {
		command.setSecondWord("Medalliom");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You have taken the magical medallion of Zue!" + "\nCongratulations for finishing the dungeon!\n",
				output);
	}

	/**
	 * Tests execute by item is too heavy or will make the inventory full.
	 */
	public void testExecuteCantTake() {
		command.setSecondWord("axe");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Inventory is full.\n" + "Please drop an item to pick-up axe\n", output);
	}

	/**
	 * Tests execute by taking a UsableItem
	 */
	public void testExecuteTakeItem() {
		command.setSecondWord("shield");
		command.execute(p);
		assertEquals(r1.getItem("shield"), p.getInventory().getUsableItem("shield"));
	}

	/**
	 * Tests execute by trying to take a non UsableItem type
	 */
	public void testExecuteNoInteractionItem() {
		command.setSecondWord("table");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You can't pick this item.\n", output);
	}
}
