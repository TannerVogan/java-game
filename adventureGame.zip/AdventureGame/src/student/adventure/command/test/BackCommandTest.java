package student.adventure.command.test;

import student.adventure.DungeonRoom;
import student.adventure.character.Monster;
import student.adventure.command.BackCommand;
import student.adventure.player.AdventureParty;

/**
 * BackCommandTest is a JUnit test class for BackCommand.
 *
 */
public class BackCommandTest extends student.TestCase {
	private BackCommand command;
	private AdventureParty p;
	private DungeonRoom r1;

	/**
	 * Create a new BackCommandTest object.
	 */
	public BackCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		command = new BackCommand();
		p = new AdventureParty();
		r1 = new DungeonRoom("Room 1");

		r1.setExit("north", new DungeonRoom("Room 2"));

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests the execute method contains a monster
	 */
	public void testExecuteContainsMonster() {
		r1.addMonster(new Monster("Urzael", "A man eating ogre", 5, 5, 100, null));
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals(
				"\nYou are Room 1.\nExits: north\n\tYou can't move! You have "
						+ "engaged in combat!\n\tUse the flee command to move again." + "\nMonsters: Urzael \n",
				output);
	}

	/**
	 * Tests the execute method while the player's previous room is null
	 */
	public void testExecutePreviousRoomNull() {
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("\nYou are still in the same room as when the game started!\n", output);
	}

	/**
	 * Tests the execute method while the player's previous room is not null
	 */
	public void testExecutePreviousRoomNotNull() {
		p.walk("north");
		command.execute(p);
		assertEquals(r1, p.getCurrentRoom());
	}
}
