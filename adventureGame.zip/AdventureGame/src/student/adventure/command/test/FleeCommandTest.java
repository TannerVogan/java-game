package student.adventure.command.test;

import student.TestableRandom;
import student.adventure.DungeonRoom;
import student.adventure.character.Monster;
import student.adventure.command.FleeCommand;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * FleeCommandTest is a JUnit test class for FleeCommand.
 *
 */
public class FleeCommandTest extends student.TestCase {
	private FleeCommand command;
	private AdventureParty p;
	private DungeonRoom r1;

	/**
	 * Create a new DropCommandTest object.
	 */
	public FleeCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		command = new FleeCommand();
		p = new AdventureParty();
		r1 = new DungeonRoom("Room 1");

		DungeonRoom r2 = new DungeonRoom("Room 2");
		DungeonRoom r3 = new DungeonRoom("Room 3");
		DungeonRoom r4 = new DungeonRoom("Room 4");
		DungeonRoom r5 = new DungeonRoom("Room 5");

		r1.addMonster(new Monster("Sarcutus", "An ugly man eating ogre.", 6, 3, 25, new UsableItem[0]));

		r1.setExit("north", r2);
		r1.setExit("west", r3);
		r1.setExit("east", r4);
		r1.setExit("south", r5);

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests the execute method doesn't have a second word
	 */
	public void testExecuteDoesntHaveSecondWord() {
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals(r1.getLongDescription() + "\nYou didn't specify which direction to run!\n", output);
	}

	/**
	 * Tests the execute method doesn't contain a monster
	 */
	public void testExecuteDoesntContainMonster() {
		r1.removeMonster("Sarcutus");
		command.setSecondWord("Sarcutus");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("What are you running from?\n", output);
	}

	/**
	 * Tests the random flee chance of the execute method when fleeing fails
	 */
	public void testExecuteFleeChanceFails() {
		TestableRandom.setNextInts(8);
		command.setSecondWord("Sarcutus");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Fleeing has failed!\n" + "Sarcutus did 4 damage to Hokie Warrior\n"
				+ "Hokie Warrior's health: 96\n" + "Sarcutus's health: 25\n", output);
	}

	/**
	 * Tests the random flee chance of the execute method when fleeing passes
	 */
	public void testExecuteFleeChancePasses() {
		TestableRandom.setNextInts(2);
		command.setSecondWord("Sarcutus");
		command.execute(p);
		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the default cardinal values.
	 * Default cardinal values are east, north, south and west.
	 */
	public void testExecuteNorth() {
		command.setSecondWord("north");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction s.
	 */
	public void testExecuteS() {
		command.setSecondWord("s");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction e.
	 */
	public void testExecuteE() {
		command.setSecondWord("e");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction w.
	 */
	public void testExecuteW() {
		command.setSecondWord("w");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction u.
	 */
	public void testExecuteU() {
		command.setSecondWord("u");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction d.
	 */
	public void testExecuteD() {
		command.setSecondWord("d");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction up.
	 */
	public void testExecuteUp() {
		command.setSecondWord("up");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction down.
	 */
	public void testExecuteDown() {
		command.setSecondWord("down");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of FleeCommand with the cardinal direction n.
	 */
	public void testExecuteN() {
		command.setSecondWord("n");
		command.execute(p);

		assertEquals(r1, p.getCurrentRoom());
	}

}
