package student.adventure.command.test;

import student.adventure.command.InventoryCommand;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * InventoryCommandTest is a JUnit test class for InventoryCommand.
 *
 */
public class InventoryCommandTest
    extends student.TestCase
{

    private InventoryCommand cmd;
    private AdventureParty   p;


    /**
     * Create a new InventoryCommandTest object.
     */
    public InventoryCommandTest()
    {
        // Empty constructor
    }


    /**
     * Sets up the test fixture. Called before every test case method.
     */
    public void setUp()
    {
        p = new AdventureParty();
        cmd = new InventoryCommand();
    }


    /**
     * Tests the execute method of the InventoryCommand class
     */
    public void testExecute()
    {
        p.getInventory().addUsableItem(
            new UsableItem("potion", "a health potion", "health", 30, 1));

        cmd.execute(p);

        assertEquals("Inventory: potion | \n\n", systemOut().getHistory());
    }

}
