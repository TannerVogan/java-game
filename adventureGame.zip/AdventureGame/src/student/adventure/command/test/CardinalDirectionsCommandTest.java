package student.adventure.command.test;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.TextAdventureGame;
import student.adventure.command.CardinalDirectionsCommand;
import student.adventure.player.AdventureParty;

/**
 * CardinalDirectionsCommandTest is a test class for CardinalDirectionsCommand.
 * Test class that tests all aspects of CardinalDirectionsCommand.
 *
 */
public class CardinalDirectionsCommandTest extends student.TestCase {
	private Command cmd;
	private TextAdventureGame game;
	private AdventureParty p;
	private DungeonRoom r1;
	private DungeonRoom r2;

	/**
	 * Create a new CardinalDirectionsCommandTest object.
	 */
	public CardinalDirectionsCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		game = new TextAdventureGame();
		p = new AdventureParty();

		r1 = new DungeonRoom("Room 1");
		r2 = new DungeonRoom("Room 2");

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests the execute method by using the north command
	 */
	public void testExecuteNorth() {
		r1.setExit("north", r2);
		cmd = game.parser().commandWords().get("north");
		cmd.execute(p);
		assertEquals(r2, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method by using the up command
	 */
	public void testExecuteUp() {
		r1.setExit("up", r2);
		cmd = game.parser().commandWords().get("up");
		cmd.execute(p);
		assertEquals(r2, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method by using the down command
	 */
	public void testExecuteDown() {
		r1.setExit("down", r2);
		cmd = game.parser().commandWords().get("down");
		cmd.execute(p);
		assertEquals(r2, p.getCurrentRoom());
	}

	/**
	 * Tests the execute method of Fighter with no exit in the room.
	 */
	public void testExecuteRoomNull() {
		cmd = new CardinalDirectionsCommand("null");
		p.setCurrentRoom(r2);
		cmd.execute(p);

		String output = systemOut().getHistory();

		assertEquals("\nThis room doesn't contain that exit!" + "\nPlease enter a new command.\n", output);
	}
}
