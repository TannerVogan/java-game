package student.adventure.command.test;

import student.adventure.DungeonRoom;
import student.adventure.character.Monster;
import student.adventure.command.AttackCommand;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

/**
 * AttackCommandTest is a JUnit test class for AttackCommand.
 *
 */
public class AttackCommandTest extends student.TestCase {

	private AttackCommand command;
	private AdventureParty p;
	private DungeonRoom r1;

	/**
	 * Create a new AttackCommandTest object.
	 */
	public AttackCommandTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		command = new AttackCommand();
		p = new AdventureParty();
		r1 = new DungeonRoom("Room 1");

		r1.addMonster(new Monster("Sarcutus", "An ugly man eating ogre.", 6, 3, 25,
				new UsableItem[] { new UsableItem("potion", "a health potion", "potion", 50, 1.00) }));

		p.setCurrentRoom(r1);
	}

	/**
	 * Tests execute attack monster specified
	 */
	public void testExecuteAttackMonster() {
		command.setSecondWord("Sarcutus");
		command.execute(p);
		assertEquals(16, r1.getMonster("Sarcutus").getHealth());
	}

	/**
	 * Tests execute monster doesn't exist in the room
	 */
	public void testExecuteMonsterNull() {
		command.setSecondWord("Sarc");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("Monster doesn't exist in this room!\n", output);
	}

	/**
	 * Tests execute has no second word
	 */
	public void testExecuteNoSecondWord() {
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("You must specify the monster's name in which you wish to " + "attack.\nexample: attack goblin1\n",
				output);
	}

	/**
	 * Tests execute method while the monster has zero health
	 */
	public void testExecuteMonsterHealthZero() {
		r1.getMonster("Sarcutus").setHealth(0);
		command.setSecondWord("Sarcutus");
		command.execute(p);
		String output = systemOut().getHistory();
		assertEquals("\nHokie Warrior did 9 damage to Sarcutus" + "\nYou have killed Sarcutus\n", output);
	}

	/**
	 * Tests execute method while the monster has an item
	 */
	public void testExecuteMonsterHasItem() {
		UsableItem[] item = r1.getMonster("Sarcutus").getItems();
		r1.getMonster("Sarcutus").setHealth(0);
		command.setSecondWord("Sarcutus");
		command.execute(p);
		assertEquals(item[0], r1.getItem("potion"));
	}

	/**
	 * Tests execute method while the monster doesn't have an item
	 */
	public void testExecuteMonsterDoesntHasItem() {
		r1.addMonster(new Monster("Urzael", "An ugly man eating ogre.", 6, 3, 25, null));

		r1.getMonster("Urzael").setHealth(0);
		command.setSecondWord("Urzael");
		r1.getMonster("Urzael").dropItems(r1);
		assertEquals("Items: \n", r1.getItemsDescription());
	}
}
