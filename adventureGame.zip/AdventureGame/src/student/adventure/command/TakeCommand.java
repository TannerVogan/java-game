package student.adventure.command;

import student.adventure.Command;
import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.item.Item;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

public class TakeCommand extends Command {

	@Override
	public boolean execute(Player p) {
		AdventureParty player = (AdventureParty) p;
		DungeonRoom room = player.getCurrentRoom();

		if (hasSecondWord()) {
			Item item = room.getItem(getSecondWord());

			if (item.getName().equalsIgnoreCase("Medallion")) {
				System.out.println("You have taken the magical medallion of Zue!"
						+ "\nCongratulations for finishing the dungeon!");
				return true;
			} else if (item instanceof UsableItem) {
				player.addUsableItem((UsableItem) item);
			} else {
				System.out.println("You can't pick this item up.");
			}
		} else {
			System.out.println("You must specify which item to take.");
			System.out.println("example: take potion");
		}

		return false;
	}
}
