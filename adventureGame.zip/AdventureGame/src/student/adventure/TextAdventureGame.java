package student.adventure;

import student.adventure.CommandWords;
import student.adventure.Game;
import student.adventure.GoCommand;
import student.adventure.HelpCommand;
import student.adventure.Parser;
import student.adventure.QuitCommand;
import student.adventure.character.Monster;
import student.adventure.character.MonsterDictionary;
import student.adventure.command.AttackCommand;
import student.adventure.command.BackCommand;
import student.adventure.command.CardinalDirectionsCommand;
import student.adventure.command.DropCommand;
import student.adventure.command.EquipCommand;
import student.adventure.command.FleeCommand;
import student.adventure.command.InventoryCommand;
import student.adventure.command.TakeCommand;
import student.adventure.command.ViewCommand;
import student.adventure.item.Item;
import student.adventure.item.ItemDictionary;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;

public class TextAdventureGame extends Game {
	private ItemDictionary itemDictionary;
	private MonsterDictionary monsterDictionary;

	public TextAdventureGame() {
		super(new AdventureParty(), new Parser());
		itemDictionary = ItemDictionary.getInstance();
		monsterDictionary = MonsterDictionary.getInstance();
	}

	@Override
	public void createCommands() {
		CommandWords commands = parser().commandWords();
		commands.addCommand("go", new GoCommand());
		commands.addCommand("quit", new QuitCommand());
		commands.addCommand("back", new BackCommand());
		commands.addCommand("north", new CardinalDirectionsCommand("north"));
		commands.addCommand("east", new CardinalDirectionsCommand("east"));
		commands.addCommand("south", new CardinalDirectionsCommand("south"));
		commands.addCommand("west", new CardinalDirectionsCommand("west"));
		commands.addCommand("up", new CardinalDirectionsCommand("up"));
		commands.addCommand("down", new CardinalDirectionsCommand("down"));
		commands.addCommand("n", new CardinalDirectionsCommand("north"));
		commands.addCommand("e", new CardinalDirectionsCommand("east"));
		commands.addCommand("s", new CardinalDirectionsCommand("south"));
		commands.addCommand("w", new CardinalDirectionsCommand("west"));
		commands.addCommand("u", new CardinalDirectionsCommand("up"));
		commands.addCommand("d", new CardinalDirectionsCommand("down"));
		commands.addCommand("attack", new AttackCommand());
		commands.addCommand("take", new TakeCommand());
		commands.addCommand("drop", new DropCommand());
		commands.addCommand("flee", new FleeCommand());
		commands.addCommand("view", new ViewCommand());
		commands.addCommand("equip", new EquipCommand());
		commands.addCommand("inventory", new InventoryCommand());
		commands.addCommand("i", new InventoryCommand());
		commands.addCommand("help", new HelpCommand(commands));
	}

	@Override
	public void createRooms() {
		DungeonRoom dungeonEntrance = new DungeonRoom("outside of a door, you're about to enter the terrifying dungeon ");

		DungeonRoom dungeonRoom1 = new DungeonRoom(
				"You're in a dark empty room with mold and dirt covering the walls.");
		dungeonRoom1.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom1.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom1.addItem(itemDictionary.getItem("Skeleton2"));

		DungeonRoom dungeonRoom2 = new DungeonRoom("in a tunnel long snaky path lit by torches");

		dungeonRoom2.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom2.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom2.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom2.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom2.addItem(itemDictionary.getItem("Torch"));

		DungeonRoom dungeonRoom3 = new DungeonRoom(
				"in a big room with two pairs of shackles attached to " + "the walls");
		dungeonRoom3.addItem(itemDictionary.getItem("Carcuse"));
		dungeonRoom3.addItem(itemDictionary.getItem("Shackle"));
		dungeonRoom3.addItem(itemDictionary.getItem("Shackle"));
		dungeonRoom3.addItem(itemDictionary.getItem("Table"));
		dungeonRoom3.addMonster(monsterDictionary.get("Goblin1"));
		dungeonRoom3.addMonster(monsterDictionary.get("Goblin2"));
		dungeonRoom3.addMonster(monsterDictionary.get("Goblin3"));

		DungeonRoom dungeonRoom4 = new DungeonRoom("in a dark room with a forge for making armor and weapons");
		dungeonRoom4.addItem(itemDictionary.getItem("Forge"));
		dungeonRoom4.addItem(itemDictionary.getItem("Anvil"));
		dungeonRoom4.addItem(itemDictionary.getUsableItem("Broad Axe"));
		dungeonRoom4.addMonster(monsterDictionary.get("Urzael"));

		DungeonRoom dungeonRoom5 = new DungeonRoom("In a room covered in blood from the shredded carcuses with chains "
				+ "and\nshackles lying on the ground. You also notice a large " + "number of\ntorturing devices like "
				+ "guillitine");
		dungeonRoom5.addItem(itemDictionary.getItem("Guillitine"));
		dungeonRoom5.addItem(itemDictionary.getItem("Carcuse"));
		dungeonRoom5.addItem(itemDictionary.getItem("Shackle"));
		dungeonRoom5.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom5.addMonster(monsterDictionary.get("Sarcutus"));

		DungeonRoom dungeonRoom6 = new DungeonRoom("in an empty room full of bones on the floor");
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton1"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton1"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton1"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton1"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton2"));
		dungeonRoom6.addItem(itemDictionary.getItem("Skeleton1"));

		DungeonRoom dungeonRoom7 = new DungeonRoom("in a large hall with a fabulous rug leading to a huge door");

		DungeonRoom dungeonRoom8 = new DungeonRoom(
				"in a large room with a throne made of ivory and decorated with " + "beautiful stones");
		dungeonRoom8.addItem(itemDictionary.getItem("Throne"));
		dungeonRoom8.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom8.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom8.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom8.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom8.addMonster(monsterDictionary.get("Mathiel"));

		DungeonRoom dungeonRoom9 = new DungeonRoom("in a room with a pedestal in the center of the room containing "
				+ "the \nmagneficent pendant of Tyrael");
		dungeonRoom9.addItem(itemDictionary.getItem("Pendant"));
		dungeonRoom9.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom9.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom9.addItem(itemDictionary.getItem("Torch"));
		dungeonRoom9.addItem(itemDictionary.getItem("Torch"));

		dungeonEntrance.setExit("north", dungeonRoom1);
		dungeonRoom1.setExit("north", dungeonRoom2);
		dungeonRoom2.setExit("north", dungeonRoom3);
		dungeonRoom3.setExit("east", dungeonRoom4);
		dungeonRoom3.setExit("north", dungeonRoom7);
		dungeonRoom3.setExit("west", dungeonRoom6);
		dungeonRoom5.setExit("east", dungeonRoom7);
		dungeonRoom6.setExit("north", dungeonRoom5);
		dungeonRoom7.setExit("north", dungeonRoom8);
		dungeonRoom7.setExit("west", dungeonRoom5);
		dungeonRoom8.setExit("north", dungeonRoom9);

		// the player starts the game outside
		player().setCurrentRoom(dungeonEntrance);
	}

	@Override
	public String welcomeMessage() {
		return "Welcome to The World of Dungeons!\n\n" + "This is a new adventure game where you"
				+ "\nmust explore the terrifying dungeon, slay mythical monsters "
				+ "and\nfight an ancient warrior in order to collect " + "Zue's Medallion \nand win the game.\n\n"
				+ "Type 'help' if you " + "need help.";
	}

	/**
	 * Adds the items for this game to the item dictionary
	 */
	public void createItems()

	{
		itemDictionary.add(new Item("Shackle", "A set of shackles chained to the wall."));
		itemDictionary.add(new Item("Chair", "An old wooden chair."));
		itemDictionary.add(new Item("Table", "An old wooden table."));
		itemDictionary.add(new Item("Torch", "A piece of wood soaked in tallow."));
		itemDictionary.add(new Item("Candle", "A lit candle."));
		itemDictionary.add(new Item("Guillitine", "An old torturing device for cutting heads."));
		itemDictionary.add(new Item("Cell", "An enclosed wall with bars and a locked door."));
		itemDictionary.add(new Item("Skeleton1", "Framework of bones containing the body of an Ogre."));
		itemDictionary.add(new Item("Skill Book", "A book containing a magical power."));
		itemDictionary.add(new Item("Skeleton2", "Framework of bones containing the body of a human."));
		itemDictionary.add(new Item("Throne", "A place of superior chair for a sovereign."));
		itemDictionary.add(new Item("Carcuse", "The remains of a bear."));
		itemDictionary.add(new Item("Forge", "Hot firey furnace for making weapons and armor."));
		itemDictionary.add(new Item("Anvil", "solid iron block with a flat top, concave sides, and a pointed"
				+ " end, which is for molding weapons and armor."));
		itemDictionary.add(new UsableItem("Potion", "A drinkable health potion.", "health", 50, 2.00));
		itemDictionary.add(new UsableItem("Buckler", "A small metal shield.", "defense", 5, 5.00));
		itemDictionary.add(new UsableItem("Helmet1",
				"Andariel's helm containing a mythical power from the slain " + "monster Andariel.", "defense", 3,
				3.00));
		itemDictionary.add(new UsableItem("Longsword", "A heavy steel sword that is long.", "attack", 5, 7.00));
		itemDictionary.add(new UsableItem("Medallion", "Zue's magical medallion.", "health", 20, 1.50));
		itemDictionary.add(new UsableItem("Axe", "A very sharp double sided axe.", "attack", 5, 4.00));
	}

	/**
	 * Adds the monsters for this game to the dictionary
	 */
	public void createMonsters() {

		monsterDictionary.add(new Monster("Urzael", "An ugly orc warrior with human characteristics.", 3, 3, 15,
				new UsableItem[] { itemDictionary.getUsableItem("Potion") }));
		monsterDictionary.add(new Monster("Sarcutus", "An ugly man eating ogre.", 6, 3, 25, new UsableItem[] {
				itemDictionary.getUsableItem("Potion"), itemDictionary.getUsableItem("Longsword") }));
		monsterDictionary.add(new Monster("Goblin1", "A weak, mischievous, ugly goblin.", 2, 2, 12, null));
		monsterDictionary.add(new Monster("Mathiel", "An ancient fearless ogre warrior with supernatural strength.", 10,
				6, 40,
				new UsableItem[] { itemDictionary.getUsableItem("Potion"), itemDictionary.getUsableItem("Helmet1") }));
		monsterDictionary.add(new Monster("Goblin2", "A weak, mischievous, ugly goblin.", 2, 2, 10, null));
		monsterDictionary.add(new Monster("Goblin3", "A weak, mischievous, ugly goblin.", 2, 2, 8, null));
	}

	/**
	 * The main method for the JVM
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		TextAdventureGame game = new TextAdventureGame();
		game.createItems();
		game.createMonsters();
		game.play();
	}
}
