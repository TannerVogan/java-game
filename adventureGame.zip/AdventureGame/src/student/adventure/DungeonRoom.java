package student.adventure;

import java.util.ArrayList;
import student.adventure.Room;
import student.adventure.character.Monster;
import student.adventure.item.Item;

public class DungeonRoom extends Room {
	private ArrayList<Item> items;
	private ArrayList<Monster> monsters;

	/**
	 * Create a new DungeonRoom object.
	 *
	 */
	public DungeonRoom(String description) {
		super(description);
		items = new ArrayList<Item>();
		monsters = new ArrayList<Monster>();
	}

	/**
	 * Add a monster to the room
	 * 
	 */
	public void addMonster(Monster monster) {
		monsters.add(monster);
	}

	/**
	 * Add an item to the room
	 *
	 */
	public void addItem(Item item) {
		items.add(item);
	}

	/**
	 * Remove monster from the room
	 *
	 */
	public void removeMonster(String name) {
		for (int i = 0; i < monsters.size(); i++) {
			if (monsters.get(i).getName().equals(name)) {
				monsters.remove(i);
			}
		}
	}

	/**
	 * Remove an item from the room
	 *
	 */
	public void removeItem(String name) {
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).getName().equals(name)) {
				items.remove(i);
			}
		}
	}

	/**
	 * Get the monster in the room by the specified name
	 *
	 */
	public Monster getMonster(String name) {
		for (Monster m : monsters) {
			if (m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		return null;
	}

	/**
	 * Returns all the monsters in this room
	 *
	 */
	public ArrayList<Monster> getMonsters() {
		return monsters;
	}

	/**
	 * Get the item in the room
	 *
	 */
	public Item getItem(String name) {
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i).getName().equalsIgnoreCase(name)) {
				return items.get(i);
			}
		}
		return null;
	}

	/**
	 * Returns whether the room contains a monster or not
	 *
	 */
	public boolean containsMonster() {
		return monsters.size() > 0;
	}

	/**
	 * Returns a string representation of all the monsters within the room
	 *
	 */
	public String getMonstersDescription() {
		StringBuilder sb = new StringBuilder();

		sb.append("\nMonsters: ");

		for (Monster monster : monsters) {
			sb.append(monster.getStats()).append("\n");
		}
		return sb.toString();
	}

	/**
	 * Returns a string representation of all the items within the room
	 *
	 */
	public String getItemsDescription() {
		StringBuilder sb = new StringBuilder();

		sb.append("Items: ");

		for (Item item : items) {
			sb.append(item.getName()).append(" | ");
		}
		sb.append("\n");

		return sb.toString();
	}

	@Override
	public DungeonRoom getExit(String direction) {
		return (DungeonRoom) super.getExit(direction);
	}
}
