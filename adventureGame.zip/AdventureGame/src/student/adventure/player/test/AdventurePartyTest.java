package student.adventure.player.test;

import student.adventure.DungeonRoom;
import student.adventure.character.Hero;
import student.adventure.character.Monster;
import student.adventure.item.UsableItem;
import student.adventure.player.AdventureParty;
import student.adventure.player.Inventory;

/**
 * AdventurePartyTest class is used to test the AdventureParty class
 *
 */
public class AdventurePartyTest extends student.TestCase {

	private AdventureParty party;
	private UsableItem item;
	private DungeonRoom room1;

	/**
	 * Create a new AdventurePartyTest object.
	 */
	public AdventurePartyTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		party = new AdventureParty();
		item = new UsableItem("Axe", "A very sharp double sided axe.", "attack", 5, 4.00);
		room1 = new DungeonRoom("the first room");

		room1.addMonster(new Monster("Sarcutus", "An ugly man eating ogre.", 6, 3, 25, new UsableItem[] { item }));
		room1.setExit("north", new DungeonRoom("the second room"));
		party.setCurrentRoom(room1);
	}

	/**
	 * Tests the getInventory method
	 */
	public void testGetInventory() {
		Inventory inventory = party.getInventory();

		inventory.addUsableItem(item);
		party.addUsableItem(item);

		assertEquals(inventory.getDescription(), party.getInventory().getDescription());
	}

	/**
	 * Tests the getHero method
	 */
	public void testGetHero() {
		Hero hero = party.getHero();

		hero.setAttack(200);
		party.getHero().setAttack(200);

		assertEquals(hero.getStats(), party.getHero().getStats());
	}

	/**
	 * Tests the addUsableItem method
	 */
	public void testAddUsableItem() {
		party.addUsableItem(item);

		assertEquals(item, party.getInventory().getUsableItem(item.getName()));
	}

	/**
	 * Tests the walk method when the room contains a monster
	 */
	public void testWalkContainsMonster() {
		room1.removeMonster("Sarcutus");
		party.walk("north");
		String output = systemOut().getHistory();
		assertEquals("\nYou are the second room.\nExits:\n", output);
	}

	/**
	 * Tests the walk method when the room doesn't contain a monster
	 */
	public void testWalkDoesntContainMonster() {
		party.walk("north");
		String output = systemOut().getHistory();
		assertEquals("\nYou are the first room.\nExits: north\n\t"
				+ "You can't move! You have engaged in combat!\n\tUse the flee"
				+ " command to move again.\nMonsters: Sarcutus \n", output);
	}

	/**
	 * Tests the getPreviousRoom method
	 */
	public void testPreviousRoom() {
		room1.removeMonster("Sarcutus");
		party.walk("north");
		assertEquals(room1, party.getPreviousRoom());
	}

	/**
	 * Tests the getCurrentRoom method
	 */
	public void testGetCurrentDungeonRoom() {
		assertEquals(room1, party.getCurrentRoom());
	}
}
