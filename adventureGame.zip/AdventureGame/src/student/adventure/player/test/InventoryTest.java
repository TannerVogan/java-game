package student.adventure.player.test;

import student.adventure.item.UsableItem;
import student.adventure.player.Inventory;

/**
 * InventoryTest class is used to test the Inventory class
 *
 */
public class InventoryTest extends student.TestCase {
	private Inventory in;

	/**
	 * Create a new InventoryTest object.
	 */
	public InventoryTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		in = new Inventory();
		in.addUsableItem(new UsableItem("potion", "A potion for healing health", "health", 20, 1.50));

	}

	/**
	 * Tests the removeUsableItem method of the Inventory class
	 */
	public void testRemoveUsableItem() {
		in.removeUsableItem(in.getUsableItem("potion"));
		assertEquals(null, in.getUsableItem("potion"));
	}

	/**
	 * Tests the getUsableItem method of the Inventory class
	 */
	public void testGetUsableItem() {
		assertEquals(in.getUsableItem("potion"), in.getUsableItem("potion"));
	}

	/**
	 * Tests the getInventoryWeight method of the Inventory class
	 */
	public void testGetInventoryWeight() {
		assertEquals(1.50, in.getInventoryWeight(), .001);
	}

	/**
	 * Tests the addUsableItem method of the Inventory class
	 */
	public void testAddUsableItem() {
		in.addUsableItem(new UsableItem("buckler", "a shield", "defense", 5, 5.00));
		assertEquals(in.getUsableItem("buckler"), in.getUsableItem("buckler"));
	}

	/**
	 * Tests the getDescription method
	 */
	public void testGetDescription() {
		assertEquals("Inventory: potion | \n", in.getDescription());
	}

}
