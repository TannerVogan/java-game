package student.adventure.player;

import java.util.HashMap;

import student.adventure.DungeonRoom;
import student.adventure.Player;
import student.adventure.character.Hero;
import student.adventure.character.Monster;
import student.adventure.item.UsableItem;

public class AdventureParty extends Player {
	private static final double MAX_WEIGHT = 10.0;

	private Inventory inventory;

	private Hero hero;

	private DungeonRoom previousRoom;

	/**
	 * Create a new AdventureParty object.
	 */
	public AdventureParty() {
		inventory = new Inventory();
		previousRoom = null;
		hero = new Hero("Hokie Warrior", "a fearless warrior with magical powers who seeks to destroy all evil.",
				10, 5, 100, new HashMap<String, UsableItem>());
	}

	/**
	 *
	 * @return The inventory of this player
	 */
	public Inventory getInventory() {
		return inventory;
	}

	/**
	 *
	 * @return The hero of this player
	 */
	public Hero getHero() {
		return hero;
	}

	/**
	 *
	 * @param item
	 *            The item to add to inventory
	 */
	public void addUsableItem(UsableItem item) {
		if (inventory.getInventoryWeight() + item.getWeight() <= MAX_WEIGHT) {
			inventory.addUsableItem(item);
		} else {
			System.out.println("Inventory is full.");
			System.out.println("Please drop an item to pick-up " + item.getName());
		}
	}

	@Override
	public void walk(String direction) {
		DungeonRoom room = getCurrentRoom();

		if (room.containsMonster()) {
			System.out.println();
			System.out.println(getCurrentRoom().getLongDescription());
			System.out.println("\tYou can't move! You have engaged in combat!");
			System.out.println("\tUse the flee command to move again.");
			System.out.print("Monsters:");
			for (Monster m : room.getMonsters()) {
				System.out.print(" " + m.getName() + " ");
			}
			System.out.println();
		} else {
			previousRoom = room;
			room = room.getExit(direction);
			setCurrentRoom(room);
			System.out.println();
			System.out.println(room.getLongDescription());
		}
	}

	/**
	 *
	 * @return The room the player just left
	 */
	public DungeonRoom getPreviousRoom() {
		return previousRoom;
	}

	@Override
	public DungeonRoom getCurrentRoom() {
		return (DungeonRoom) super.getCurrentRoom();
	}
}
