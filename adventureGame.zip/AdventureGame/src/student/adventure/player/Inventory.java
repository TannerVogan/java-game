package student.adventure.player;

import java.util.ArrayList;

import student.adventure.item.UsableItem;

public class Inventory {

	private ArrayList<UsableItem> items;

	/**
	 * Create a new Inventory object.
	 */
	public Inventory() {
		items = new ArrayList<UsableItem>();
	}

	/**
	 * @param item
	 *            The item to add
	 */
	public void addUsableItem(UsableItem item) {
		items.add(item);
	}

	/**
	 *
	 * @param item
	 *            The item to remove
	 */
	public void removeUsableItem(UsableItem item) {
		items.remove(items.indexOf(item));
	}

	/**
	 *
	 * @param name
	 *            The name of the item to get
	 * @return Return the UsableItem or null if doesn't exist
	 */
	public UsableItem getUsableItem(String name) {
		for (UsableItem item : items) {
			if (item.getName().equalsIgnoreCase(name)) {
				return item;
			}
		}
		return null;
	}

	/**
	 *
	 * @return The weight of all the items combined
	 */
	public double getInventoryWeight() {
		double weight = 0;

		for (UsableItem item : items) {
			weight += item.getWeight();
		}
		return weight;
	}

	/**
	 *
	 * @return A string representation of all the items
	 */
	public String getDescription() {
		StringBuilder sb = new StringBuilder();

		sb.append("Inventory: ");

		for (UsableItem item : items) {
			sb.append(item.getName()).append(" | ");
		}
		sb.append("\n");

		return sb.toString();
	}
}
