package student.adventure.character;

import java.util.HashMap;

public class MonsterDictionary {
	private static final MonsterDictionary INSTANCE = new MonsterDictionary();

	private HashMap<String, Monster> monsters;

	/**
	 * Create a new MonsterDictionary object privately. Private constructor to
	 * prevent any applications from creating a new instance.
	 */
	private MonsterDictionary() {
		monsters = new HashMap<String, Monster>();
	}

	/**
	 *
	 * @param monster
	 *            The monster to add
	 */
	public void add(Monster monster) {
		monsters.put(monster.getName(), monster);
	}

	/**
	 *
	 * @param name
	 *            The name of the monster to retrieve
	 * @return Returns the selected monster
	 */
	public Monster get(String name) {
		if (monsters.containsKey(name)) {
			return monsters.get(name);
		}
		return null;
	}

	/**
	 *
	 * @param name
	 *            The name of the monster to remove
	 */
	public void remove(String name) {
		monsters.remove(name);
	}

	/**
	 * 
	 * @return The only instance of MonsterDictionary
	 */
	public static MonsterDictionary getInstance() {
		return INSTANCE;
	}
}
