package student.adventure.character;

import java.util.Map;

import student.adventure.item.UsableItem;

public class Hero extends Fighter {
	/**
	 * Items equipped by the hero
	 */
	Map<String, UsableItem> items;

	/**
	 * Create a new Hero object.
	 *
	 */

	public Hero(String name, String description, int attack, int defense, int health, Map<String, UsableItem> items) {
		super(name, description, attack, defense, health);
		this.items = items;
	}

	/**
	 * Private method to calculateStats when the hero equips a new item.
	 */
	private void calculateStats() {
		for (String s : items.keySet()) {
			UsableItem item = items.get(s);
			if (item.getPower().equals("attack")) {
				setAttack(getAttack() + item.getBoost());
			} else if (item.getPower().equals("defense")) {
				setDefense(getDefense() + item.getBoost());
			} else if (item.getPower().equals("health")) {
				setHealth(getHealth() + item.getBoost());
			} else {
				System.out.println("Remove item " + item.getName() + " from your hero.");
				System.out.println(
						"Only items that are shield, helmet, weapon or " + "pendant should be added to a hero.");
			}
		}
	}

	/**
	 * Changes the selected item to a new item
	 *
	 */
	public UsableItem changeEquipment(String location, UsableItem item) {
		UsableItem currentItem = items.get(location);
		items.put(location, item);
		calculateStats();
		return currentItem;
	}

	/**
	 * This hero attacks the specified fighter object
	 *
	 */
	public void attack(Fighter fighter) {
		int heroDamage = getAttack() - fighter.getDefense() / 2;

		fighter.setHealth(fighter.getHealth() - heroDamage);

		System.out.println();
		System.out.println(getName() + " did " + heroDamage + " damage to " + fighter.getName());
	}

	@Override
	public String getStats() {
		StringBuilder sb = new StringBuilder();

		sb.append("Name: ").append(getName()).append(" | ").append("Attack: ").append(getAttack()).append(" | ")
				.append("Defense: ").append(getDefense()).append(" | ").append("Health: ").append(getHealth())
				.append("\n").append("Equipped Items: ");

		for (String location : items.keySet()) {
			sb.append(items.get(location).getName() + " | ");
		}
		sb.append("\n");

		return sb.toString();
	}
}
