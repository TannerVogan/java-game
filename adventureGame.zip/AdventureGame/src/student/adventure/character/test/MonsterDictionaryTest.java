package student.adventure.character.test;

import student.adventure.character.Monster;
import student.adventure.character.MonsterDictionary;

public class MonsterDictionaryTest extends student.TestCase {
	private MonsterDictionary dictionary;

	/**
	 * Create a new MonsterDictionaryTest object.
	 */
	public MonsterDictionaryTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		dictionary = MonsterDictionary.getInstance();
		dictionary.add(new Monster("Troll1", "Tough ugly creature with tough rock like skin.", 5, 5, 80, null));
		dictionary.add(new Monster("Goblin1", "A mischievous, ugly, dwarflike creature.", 1, 2, 20, null));
	}

	/**
	 * Tests the add method of the MonsterDictionary class
	 */
	public void testAdd() {
		dictionary.add(new Monster("Ogre1", "A hideous giant who feeds on human flesh", 10, 10, 100, null));
		assertEquals(dictionary.get("Ogre1"), dictionary.get("Ogre1"));
	}

	/**
	 * Tests the remove method of the MonsterDictionary class
	 */
	public void testRemove() {
		dictionary.remove("Goblin1");
		assertEquals(null, dictionary.get("Goblin1"));
	}

	/**
	 * Tests the get method of the MonsterDictionary class
	 */
	public void testGet() {
		assertEquals(dictionary.get("Troll1"), dictionary.get("Troll1"));
	}
}
