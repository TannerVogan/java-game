package student.adventure.character.test;

import student.adventure.character.Hero;
import student.adventure.character.Monster;
import student.adventure.item.UsableItem;

import java.util.HashMap;

public class HeroTest extends student.TestCase {

	private Hero hero;

	/**
	 * Create a new DungeonRoomTest object.
	 */
	public HeroTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		hero = new Hero("Jon", "A hairy old guy", 5, 5, 50, new HashMap<String, UsableItem>());
	}

	/**
	 * Tests the changeEquipment method when nothing is equipped on the hero
	 */
	public void testChangeEquipmentNothingEquipped() {
		UsableItem item = new UsableItem("Longsword", "A heavy steel sword that is long.", "attack", 5, 7.00);
		assertEquals(null, hero.changeEquipment(item.getPower(), item));
	}

	/**
	 * Tests the changeEquipment method by adding an item with the defense power
	 */
	public void testChangeEquipmentDefense() {
		UsableItem item = new UsableItem("Buckler", "A small steel shield.", "defense", 5, 7.00);
		hero.changeEquipment(item.getPower(), item);
		assertEquals(10, hero.getDefense());
	}

	/**
	 * Tests the changeEquipment method by adding an item with the attack power
	 */
	public void testChangeEquipmentAttack() {
		UsableItem item = new UsableItem("Longsword", "A heavy steel sword that is long.", "attack", 5, 7.00);
		hero.changeEquipment(item.getPower(), item);
		assertEquals(10, hero.getAttack());
	}

	/**
	 * Tests the changeEquipment method by adding an item with the health power
	 */
	public void testChangeEquipmentHealth() {
		UsableItem item = new UsableItem("Pendant", "A nice necklace.", "health", 10, 7.00);
		hero.changeEquipment(item.getPower(), item);
		assertEquals(60, hero.getHealth());
	}

	/**
	 * Tests the changeEquipment method by adding an item with an unknown power
	 */
	public void testChangeEquipmentDefault() {
		UsableItem item = new UsableItem("Gameboy", "Some item in the new generation.", "attention", 10, 7.00);
		hero.changeEquipment(item.getPower(), item);

		String output = systemOut().getHistory();
		assertEquals(
				"Please remove item Gameboy from your hero.\n"
						+ "Only items that are a helmet, shield, weapon or pendant " + "should be added to a hero.\n",
				output);
	}

	/**
	 * Tests the changeEquipment method when an item is equipped on the hero
	 */
	public void testChangeEquipment() {
		UsableItem item = new UsableItem("Longsword", "A heavy steel sword that is long.", "attack", 5, 7.00);
		UsableItem item2 = new UsableItem("Axe", "A very sharp double sided axe.", "attack", 5, 4.00);
		hero.changeEquipment(item.getPower(), item);
		assertEquals(item, hero.changeEquipment(item2.getPower(), item2));
	}

	/**
	 * Tests the getStats method
	 */
	public void testGetStats() {
		UsableItem item = new UsableItem("Axe", "A very sharp double sided axe.", "attack", 5, 4.00);
		hero.changeEquipment(item.getPower(), item);

		assertEquals("Name: Jon | Attack: 10 | Defense: 5 | Health: 50\n" + "Equipped Items: Axe | \n",
				hero.getStats());
	}

	/**
	 * Tests the attack method
	 */
	public void testAttack() {
		Monster monster = new Monster("Goblin1", "A weak, mischievous, ugly goblin.", 2, 2, 20, null);

		hero.attack(monster);

		assertEquals(16, monster.getHealth());
	}

	/**
	 * Tests the output of the attack method
	 */
	public void testAttackOutput() {
		Monster monster = new Monster("Goblin1", "A weak, mischievous, ugly goblin.", 2, 2, 20, null);

		hero.attack(monster);

		String output = systemOut().getHistory();
		assertEquals("\nJon did 4 damage to Goblin1\n", output);
	}
}
