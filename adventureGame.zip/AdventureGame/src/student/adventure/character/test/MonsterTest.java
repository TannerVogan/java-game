package student.adventure.character.test;

import student.adventure.DungeonRoom;
import student.adventure.character.Hero;
import student.adventure.character.Monster;
import student.adventure.item.UsableItem;

import java.util.HashMap;

public class MonsterTest extends student.TestCase {
	private Monster monster;

	private UsableItem[] items;

	private DungeonRoom room;

	/**
	 * Create a new ItemTest object.
	 */
	public MonsterTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		items = new UsableItem[] { new UsableItem("Health Potion", "Potion used for healing", "health", 20, 2.00),
				new UsableItem("Buckler", "A shield made of steel", "defense", 1, 2.00),
				new UsableItem("Club", "A weapon made of wood", "attack", 2, 2.00),
				new UsableItem("Medallion", "A magical necklace", "health", 50, 2.00) };

		room = new DungeonRoom("a room");

		monster = new Monster("Troll", "Tough ugly creature with tough rock like skin.", 5, 5, 80, items);
	}

	/**
	 * Tests the setAttack method of Monster
	 */
	public void testGetItems() {
		assertEquals(items, monster.getItems());
	}

	/**
	 * Tests the true condition of the dropItems method
	 */
	public void testDropItemsTrue() {
		monster.dropItems(room);
		assertEquals("Items: Health Potion | Buckler | Club | Medallion | \n", room.getItemsDescription());
	}

	/**
	 * Tests the length condition of the dropItems method
	 */
	public void testDropItemsLengthZero() {
		monster = new Monster("Troll2", "Tough ugly creature with tough rock like skin.", 5, 5, 80, new UsableItem[0]);
		monster.dropItems(room);
		assertEquals("Items: \n", room.getItemsDescription());
	}

	/**
	 * Tests the null condition of the dropItems method
	 */
	public void testDropItemsNull() {
		monster = new Monster("Troll2", "Tough ugly creature with tough rock like skin.", 5, 5, 80, null);
		assertEquals(null, monster.getItems());
	}

	/**
	 * Tests the attack method
	 */
	public void testAttack() {
		Hero hero = new Hero("John", "A hairy beast", 5, 5, 50, new HashMap<String, UsableItem>());
		monster.attack(hero);
		assertEquals(47, hero.getHealth());
	}
}
