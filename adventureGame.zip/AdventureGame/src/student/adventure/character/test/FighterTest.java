package student.adventure.character.test;

import student.adventure.character.Monster;
import student.adventure.item.UsableItem;

public class FighterTest extends student.TestCase {
	private Monster monster;

	/**
	 * Create a new FighterTest object.
	 */
	public FighterTest() {
		// Empty constructor
	}

	public void setUp() {
		monster = new Monster("Troll", "Tough ugly creature with tough rock like skin.", 3, 5, 80,
				new UsableItem[] { new UsableItem("Health Potion", "Potion used for healing", "health", 20, 2.00),
						new UsableItem("Buckler", "A shield made of steel", "defense", 1, 2.00),
						new UsableItem("Club", "A weapon made of wood", "attack", 2, 2.00),
						new UsableItem("Medallion", "A magical necklace", "health", 50, 2.00) });
	}

	/**
	 * Tests the getHealth method of Fighter
	 */
	public void testGetHealth() {
		assertEquals(80, monster.getHealth());
	}

	/**
	 * Tests the setHealth method of Fighter
	 */
	public void testSetHealth() {
		monster.setHealth(50);
		assertEquals(50, monster.getHealth());
	}

	/**
	 * Tests the getAttack method of Fighter
	 */
	public void testGetAttack() {
		assertEquals(3, monster.getAttack());
	}

	/**
	 * Tests the setAttack method of Fighter
	 */
	public void testSetAttack() {
		monster.setAttack(5);
		assertEquals(5, monster.getAttack());
	}

	/**
	 * Tests the getDefense method of Fighter
	 */
	public void testGetDefense() {
		assertEquals(5, monster.getDefense());
	}

	/**
	 * Tests the setDefense method of Fighter
	 */
	public void testSetDefense() {
		monster.setDefense(4);
		assertEquals(4, monster.getDefense());
	}

	/**
	 * Tests the getName method of Fighter
	 */
	public void testGetName() {
		assertEquals("Troll", monster.getName());
	}

	/**
	 * Tests the getDescription method of Fighter
	 */
	public void testGetdescription() {
		assertEquals("Tough ugly creature with tough rock like skin.", monster.getDescription());
	}

}
