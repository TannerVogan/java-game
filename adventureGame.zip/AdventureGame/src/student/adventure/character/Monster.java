package student.adventure.character;

import student.adventure.DungeonRoom;
import student.adventure.item.UsableItem;

public class Monster extends Fighter {
	private UsableItem[] items;

	/**
	 * Create a new Monster object.
	 *
	 */
	public Monster(String name, String description, int attack, int defense, int health, UsableItem[] items) {
		super(name, description, attack, defense, health);
		this.items = items;
	}

	/**
	 * @return The items in which this monster carries
	 */
	public UsableItem[] getItems() {
		return items;
	}

	/**
	 * 
	 * @param room
	 *            The room to obtain the items
	 */
	public void dropItems(DungeonRoom room) {
		if (items != null && items.length > 0) {
			for (UsableItem item : getItems()) {
				room.addItem(item);
			}
		}
	}

	/**
	 *
	 * @param fighter
	 *            The fighter object for this monster to attack
	 */
	public void attack(Fighter fighter) {
		int monsterDamage = getAttack() - fighter.getDefense() / 2;

		fighter.setHealth(fighter.getHealth() - monsterDamage);
		System.out.println(getName() + " did " + monsterDamage + " damage to " + fighter.getName());
		System.out.println(fighter.getName() + "'s health: " + fighter.getHealth());
		System.out.println(getName() + "'s health: " + getHealth());
	}
}
