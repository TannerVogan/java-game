package student.adventure.character;

public abstract class Fighter {
	private int health;

	private int attack;

	private int defense;

	private String name;

	private String description;

	/**
	 * Create a new Fighter object.
	 *
	 */
	public Fighter(String name, String description, int attack, int defense, int health) {
		this.name = name;
		this.description = description;
		this.attack = attack;
		this.defense = defense;
		this.health = health;
	}

	/**
	 *
	 * @return health the life of the fighter
	 */
	public int getHealth() {
		return health;
	}

	/**
	 *
	 * @return attack the damage of the fighter
	 */
	public int getAttack() {
		return attack;
	}

	/**
	 *
	 * @return defense the defense of the fighter
	 */
	public int getDefense() {
		return defense;
	}

	/**
	 *
	 * @return name the name of the fighter
	 */
	public String getName() {
		return name;
	}

	/**
	 *
	 * @return description the description of the fighter
	 */
	public String getDescription() {
		return description;
	}

	/**
	 *
	 * @param health
	 *            The new health of the fighter
	 */
	public void setHealth(int health) {
		this.health = health;
	}

	/**
	 *
	 * @param attack
	 *            The new attack of the fighter
	 */
	public void setAttack(int attack) {
		this.attack = attack;
	}

	/**
	 *
	 * @param defense
	 *            The new defense of the fighter
	 */
	public void setDefense(int defense) {
		this.defense = defense;
	}

	/**
	 * 
	 * @return String representation of the fighter stats
	 */
	public String getStats() {
		StringBuilder sb = new StringBuilder();

		sb.append("Name: ").append(getName()).append(" | ").append("Attack: ").append(getAttack()).append(" | ")
				.append("Defense: ").append(getDefense()).append(" | ").append("Health: ").append(getHealth())
				.append("\n");

		return sb.toString();
	}

	/**
	 *
	 * @param fighter
	 *            The fighter object to attack
	 */

	public abstract void attack(Fighter fighter);
}
