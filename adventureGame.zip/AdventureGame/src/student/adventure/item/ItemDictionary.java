package student.adventure.item;

import java.util.HashMap;


public class ItemDictionary
{
    private static final ItemDictionary INSTANCE = new ItemDictionary();

    private HashMap<String, Item> items;

    /**
     * Create a new ItemDictionary object privately. Private constructor to
     * prevent any applications from creating a new instance.
     */
    private ItemDictionary()
    {
        items = new HashMap<String, Item>();
    }


    /**
     *
     * @param item
     *            The item to add
     */
    public void add(Item item)
    {
        items.put(item.getName(), item);
    }

    /**
     *
     * @param name
     *            The name of the item to retrieve
     * @return Returns the item or null if not found
     */
    public Item getItem(String name)
    {
        if (items.containsKey(name))
        {
            return items.get(name);
        }
        return null;
    }


    /**
     * Returns the selected UsableItem
     * 
     * @param name
     *            The name of the usable item
     * @return Returns the usable item or null if not found
     */
    public UsableItem getUsableItem(String name)
    {
        if (items.containsKey(name) && items.get(name) instanceof UsableItem)
        {
            return (UsableItem)items.get(name);
        }
        return null;
    }


    /**
     *
     * @param name
     *            The name of the item to remove
     */
    public void remove(String name)
    {
        items.remove(name);
    }


    /**
     * 
     * @return The only instance of ItemDictionary
     */
    public static ItemDictionary getInstance()
    {
        return INSTANCE;
    }
}
