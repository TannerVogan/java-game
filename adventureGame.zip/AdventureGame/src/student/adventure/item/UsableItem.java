package student.adventure.item;

public class UsableItem extends Item {
	private final String power;

	private final int boost;

	private final double weight;

	/**
	 * @param name
	 *            The name of the item
	 * @param description
	 *            The description of the item
	 * @param power
	 *            The power of the item
	 * @param boost
	 *            The boost of the item
	 * @param weight
	 *            The weight of the item
	 */
	public UsableItem(String name, String description, String power, int boost, double weight) {
		super(name, description);
		this.power = power;
		this.boost = boost;
		this.weight = weight;
	}

	/**
	 *
	 * @return power The power of the item
	 */
	public String getPower() {
		return power;
	}

	/**
	 *
	 * @return boost The boost of the item
	 */
	public int getBoost() {
		return boost;
	}

	/**
	 *
	 * @return weight The weight of the item
	 */
	public double getWeight() {
		return weight;
	}

}
