package student.adventure.item.test;

import student.adventure.item.Item;

public class ItemTest extends student.TestCase {
	private Item item;

	/**
	 * Create a new ItemTest object.
	 */
	public ItemTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		item = new Item("Crate", "An empty crate");
	}

	/**
	 * Tests the getName method of the Item class
	 */
	public void testGetName() {
		assertEquals("Crate", item.getName());
	}

	/**
	 * Tests the getDescription method of the Item class
	 */
	public void testGetDescription() {
		assertEquals("An empty crate", item.getDescription());
	}
}
