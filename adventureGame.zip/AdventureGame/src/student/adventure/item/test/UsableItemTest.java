package student.adventure.item.test;

import student.adventure.item.UsableItem;

/**
 * UsableItemTest is a JUnit test class for UsableItem
 *
 */
public class UsableItemTest extends student.TestCase {
	private UsableItem item;

	/**
	 * Create a new ItemTest object.
	 */
	public UsableItemTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		item = new UsableItem("Health Potion", "A potion to drink for healing a character", "health", 20, 2.00);
	}

	/**
	 * Tests the getWeight method of the UsableItem class
	 */
	public void testGetWeight() {
		assertEquals(2.00, item.getWeight(), .01);
	}

	/**
	 * Tests the getPower method of the UsableItem class
	 */
	public void testGetPower() {
		assertEquals("health", item.getPower());
	}

	/**
	 * Tests the getBoost method of the UsableItem class
	 */
	public void testGetBoost() {
		assertEquals(20, item.getBoost());
	}
}
