package student.adventure.item.test;

import student.adventure.item.Item;
import student.adventure.item.ItemDictionary;
import student.adventure.item.UsableItem;

/**
 * ItemDictionaryTest is a test class used to test the ItemDictionary class.
 *
 */
public class ItemDictionaryTest extends student.TestCase {
	private ItemDictionary dictionary;

	/**
	 * Create a new ItemDictionaryTest object.
	 */
	public ItemDictionaryTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		dictionary = ItemDictionary.getInstance();
		dictionary.add(new Item("Crate", "A wooden crate"));
		dictionary.add(new Item("Table", "A wooden table"));
		dictionary.add(new UsableItem("Health Potion", "A potion used to retore health.", "health", 20, 1.50));
	}

	/**
	 * Tests the add method of the ItemDictionary class.
	 */
	public void testAdd() {
		dictionary.add(new Item("Lamp", "A tall metal lamp"));
		assertEquals(dictionary.getItem("Lamp"), dictionary.getItem("Lamp"));
	}

	/**
	 * Tests the remove method of the ItemDictionary class.
	 */
	public void testRemove() {
		dictionary.remove("Table");
		assertEquals(null, dictionary.getItem("Table"));
	}

	/**
	 * Tests the getItem method of the ItemDictionary class.
	 */
	public void testGetItem() {
		assertEquals(dictionary.getItem("Crate"), dictionary.getItem("Crate"));
	}

	/**
	 * Tests the getUsableItem method of the ItemDictionary class
	 */
	public void testGetUsableItem() {
		assertEquals(dictionary.getUsableItem("Health Potion"), dictionary.getUsableItem("Health Potion"));
	}

	/**
	 * Tests getUsableItem when item is not an instance of UsableItem.
	 */
	public void testGetUsableItemNotUsableItem() {
		assertEquals(null, dictionary.getUsableItem("Table"));
	}

	/**
	 * Tests getUsableItem when item doesn't exist.
	 */
	public void testGetUsableItemDoesntExist() {
		assertEquals(null, dictionary.getUsableItem("Snowman"));
	}

	/**
	 * Tests getItem when item doesn't exist.
	 */
	public void testGetItemNull() {
		assertEquals(null, dictionary.getItem("Laptop"));
	}
}
