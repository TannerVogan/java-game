package student.adventure.item;

public class Item {
	private final String name;

	private final String description;

	/**
	 *
	 * @param name
	 *            The name of the item
	 * @param description
	 *            The description of the item
	 */
	public Item(String name, String description) {
		this.name = name;
		this.description = description;
	}

	/**
	 *
	 * @return name The name of the item
	 */
	public String getName() {
		return name;
	}

	/**
	 *
	 * @return description The description of the item
	 */
	public String getDescription() {
		return description;
	}
}
