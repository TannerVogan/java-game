package student.adventure.test;

import student.adventure.DungeonRoom;
import student.adventure.character.Monster;
import student.adventure.item.Item;
import student.adventure.item.UsableItem;

import java.util.ArrayList;

/**
 * DungeonRoomTest class is used to test the DungeonRoom class
 *
 */
public class DungeonRoomTest extends student.TestCase {

	private DungeonRoom room;

	/**
	 * Create a new DungeonRoomTest object.
	 */
	public DungeonRoomTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		room = new DungeonRoom("A boring room");

		room.addMonster(new Monster("Urzael", "An ugly orc warrior with human characteristics.", 3, 3, 15, null));
		room.addItem(new Item("Guillitine", "An old torturing device for cutting heads."));
	}

	/**
	 * Tests addItem method
	 */
	public void testAddItem() {
		Item item = new Item("Lighter", "Sparks a flame");
		room.addItem(item);
		assertEquals(item, room.getItem(item.getName()));
	}

	/**
	 * Tests removeItem method
	 */
	public void testRemoveItem() {
		room.removeItem("Guillitine");
		assertEquals(null, room.getItem("Guillitine"));
	}

	/**
	 * Tests removeItem method when item doesn't exist
	 */
	public void testRemoveItemDoesntExist() {
		room.removeItem("G");
		assertEquals(null, room.getItem("G"));
	}

	/**
	 * Tests getItem method
	 */
	public void testGetItem() {
		Item item = new Item("Lighter", "Sparks a flame");
		room.addItem(item);
		assertEquals(item, room.getItem(item.getName()));
	}

	/**
	 * Tests addMonster method
	 */
	public void testAddMonster() {
		Monster monster = new Monster("Ogre", "An ugly orc warrior with human characteristics.", 3, 3, 15,
				new UsableItem[0]);
		room.addMonster(monster);
		assertEquals(monster, room.getMonster(monster.getName()));
	}

	/**
	 * Tests getMonster method
	 */
	public void testGetMonster() {
		Monster monster = new Monster("Ogre", "An ugly orc warrior with human characteristics.", 3, 3, 15,
				new UsableItem[0]);
		room.addMonster(monster);
		assertEquals(monster, room.getMonster(monster.getName()));
	}

	/**
	 * Tests removeMonster method
	 */
	public void testRemoveMonster() {
		room.removeMonster("Urzael");
		assertEquals(null, room.getMonster("Urzael"));
	}

	/**
	 * Tests removeMonster method when the monster doesn't exist
	 */
	public void testRemoveMonsterDoesntExist() {
		room.removeMonster("U");
		assertEquals(null, room.getMonster("U"));
	}

	/**
	 * Tests getMonsters method
	 */
	public void testGetMonsters() {
		ArrayList<Monster> monsters = new ArrayList<Monster>();
		monsters.add(room.getMonster("Urzael"));
		assertEquals(monsters, room.getMonsters());
	}

	/**
	 * Tests containsMonster method with the room containing at least one
	 * monster
	 */
	public void testContainsMonsterTrue() {
		assertTrue(room.containsMonster());
	}

	/**
	 * Tests containsMonster method with the room containing no monsters
	 */
	public void testContainsMonsterFalse() {
		room.removeMonster("Urzael");
		assertFalse(room.containsMonster());
	}

	/**
	 * Tests getMonsterDescription method
	 */
	public void testGetMonsterDescription() {
		System.out.println(room.getMonstersDescription());
		System.out.println(room.getItemsDescription());
		assertEquals("\nMonsters: Name: Urzael | Attack: 3 | Defense: 3 | Health: " + "15\n\n",
				room.getMonstersDescription());
	}

	/**
	 * Tests getItemsDescription method
	 */
	public void testGetItemsDescription() {
		assertEquals("Items: Guillitine | \n", room.getItemsDescription());
	}

}
