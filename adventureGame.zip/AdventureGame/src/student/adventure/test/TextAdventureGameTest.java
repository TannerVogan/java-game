package student.adventure.test;

import student.adventure.CommandWords;
import student.adventure.TextAdventureGame;
import student.adventure.character.MonsterDictionary;
import student.adventure.item.ItemDictionary;
import student.adventure.player.AdventureParty;

public class TextAdventureGameTest extends student.TestCase {
	private TextAdventureGame game;

	/**
	 * Create a new TextAdventureGameTest object.
	 */
	public TextAdventureGameTest() {
		// Empty constructor
	}

	/**
	 * Sets up the test fixture. Called before every test case method.
	 */
	public void setUp() {
		game = new TextAdventureGame();
	}

	/**
	 * Tests the main method
	 */
	public void testMainMethod() {
		setSystemIn("quit");
		TextAdventureGame.main(null);
		assertEquals(
				"\nWelcome to The World of Dungeons!\n\nThis is a new " + " adventure game, \nwhere "
						+ " the player will explore the terrifying dungeon, slay mythical monsters and"
						+ "\nfight with an ancient warrior in order to collect "
						+ "Zue's Medallion \nand win the game.\n\nType 'help' if you "
						+ "need help.\n\nYou are outside the door and there is a fearful "
						+ "looking dungeon.\nExits: north\n> " + "Thank you for playing.  Good bye.\n",
				systemOut().getHistory());
	}

	/**
	 * Tests the createItems method
	 */
	public void testCreateItems() {
		game.createItems();

		ItemDictionary dictionary = ItemDictionary.getInstance();

		assertEquals(dictionary.getItem("Table"), dictionary.getItem("Table"));
	}

	/**
	 * Tests the Override method welcomeMessage
	 */
	public void testWelcomeMessage() {
		assertEquals(
				"Welcome to The World of Dungeons!\n\n" + "This is a new adventure game where you "
						+ "\nmust explore the terrifying dungeon, slay mythical "
						+ "monsters and\nfight with an ancient warrior in order to "
						+ "to collect Zue's Medallion \nand win the game.\n\nType 'help'" + " if you need help.",
				game.welcomeMessage());
	}

	/**
	 * Tests the createMonsters method
	 */
	public void testCreateMonsters() {
		game.createMonsters();

		MonsterDictionary dictionary = MonsterDictionary.getInstance();

		assertEquals(dictionary.get("Urzael"), dictionary.get("Urzael"));
	}

	/**
	 * Tests the createRooms method
	 */
	public void testCreateRooms() {
		game.createRooms();

		AdventureParty party = (AdventureParty) game.player();

		assertEquals(party.getCurrentRoom(), party.getCurrentRoom());
	}

	/**
	 * Tests the createCommands method
	 */
	public void testCreateCommands() {
		CommandWords commands = game.parser().commandWords();
		commands.showAll();

		String output = systemOut().getHistory();
		assertEquals("drop  d  south  e  north  go  back  flee  i  inventory  down  n  "
				+ "take  help  east  view  s  equip  u  attack  w  west  quit  " + "up  \n",

				output);
	}
}
